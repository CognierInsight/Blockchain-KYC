#!/bin/bash

if [ ! -d "/tmp/composer" ]; then
	mkdir /tmp/composer
fi
cp networkadmin.card /tmp/composer


echo "over"
