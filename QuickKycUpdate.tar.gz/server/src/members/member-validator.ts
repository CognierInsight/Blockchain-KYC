import * as Joi from "joi";

export const createModel = Joi.object().keys({
  memberId: Joi.string().required(),
  email: Joi.string().required(),
  firstName: Joi.string().required(),
  lastName: Joi.string().required(),
  dob: Joi.date().required(),
  contact: Joi.string().required(),
  address: Joi.object().required().keys({
    street: Joi.string().required(),
    city: Joi.string().required(),
    country: Joi.string().required(),
    zip: Joi.string().required()
  })
});

export const updateModel = Joi.object().keys({
  memberId: Joi.string().required(),
  email: Joi.string().required(),
  firstName: Joi.string().required(),
  lastName: Joi.string().required(),
  contact: Joi.string().required(),
  dob: Joi.date().required(),
  address: Joi.object().required().keys({
    street: Joi.string().required(),
    city: Joi.string().required(),
    country: Joi.string().required(),
    zip: Joi.string().required()
  })
});
