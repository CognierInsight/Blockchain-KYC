export interface IKey {
  keyId: string;
  keyTypeObject:string;
  startTime: string;
  hours: number;
  endTime: string;
  views: number;
  authorized: string[];
  status:boolean;
  memberId: string;
  documentIds: string[];
  }
