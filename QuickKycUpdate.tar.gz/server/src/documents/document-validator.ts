import * as Joi from "joi";

export const createModel = Joi.object().keys({
  documentId: Joi.string().required(),
  documentName: Joi.string().required(),
  documentImage: Joi.string().required(),
  status: Joi.string().required(),
  memberId: Joi.string().required(),
  categoryId:Joi.string().required()
});

export const updateModel = Joi.object().keys({
  documentId: Joi.string().required(),
  documentName: Joi.string().required(),
  documentImage: Joi.string().required(),
  status: Joi.string().required(),
  memberId: Joi.string().required(),
  categoryId:Joi.string().required()
  //memberIds: Joi.array().optional()
});
