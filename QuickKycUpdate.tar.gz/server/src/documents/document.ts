export interface IDocument {
  documentId: string;
  documentName: string;
  documentImage: string;
  status: string;
  memberId:string;
  categoryId: string;
}