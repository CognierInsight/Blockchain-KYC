export interface ICategory {
  categoryId: string;
  categoryName: string;
  description: string;
}