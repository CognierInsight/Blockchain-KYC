export interface ITruck {
  id: string;
  code: string;
  driverId: string;
  cargoIds: string[];
}
