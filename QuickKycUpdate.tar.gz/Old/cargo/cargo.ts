export interface ICargo  {
  id: string;
  name: string;
  type: string;
}
