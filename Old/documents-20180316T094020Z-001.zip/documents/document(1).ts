

export interface Idocument {
  id: string;
  code: string;
  documentId: string;
  //cargoIds: string[];
}