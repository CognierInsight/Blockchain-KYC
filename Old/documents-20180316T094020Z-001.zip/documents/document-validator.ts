import * as Joi from "joi";

export const createModel = Joi.object().keys({
  id: Joi.string().required(),
  code: Joi.string().required(),
  documentId: Joi.string().allow('').optional(),
//  memberIds: Joi.array().optional()
});

export const updateModel = Joi.object().keys({
  id: Joi.string().required(),
  code: Joi.string().required(),
  documentId: Joi.string().allow('').optional(),
  //memberIds: Joi.array().optional()
});
/*
export const changeDriverModel = Joi.object().keys({
  docId: Joi.string().required()
});
*/
