import * as Joi from "joi";

export const createModel = Joi.object().keys({
  
  key: Joi.string().required(),
  keyTypeObject: Joi.string().required(),
  startTime:joi.date().timestamp().required(),
  hours: Joi.integer().required(),
  startTime:joi.date().timestamp().required(),
  views: Joi.integer().required(),
  authorized: Joi.string().required(),
  status: Joi.boolean().required(),
  member: Joi.string().required(),
  document: Joi.string().required()
  
  
  //keyType: Joi.enum().required(),
  
 // type: Joi.string().required()
});

export const updateModel = Joi.object().keys({
  key: Joi.string().required(),
  keyTypeObject: Joi.string().required(),
  startTime:joi.date().timestamp().required(),
  hours: Joi.integer().required(),
  startTime:joi.date().timestamp().required(),
  views: Joi.integer().required(),
  authorized: Joi.string().required(),
  status: Joi.boolean().required(),
  member: Joi.string().required(),
  document: Joi.string().required()
});
