export interface key {
  keyId: string;
  keyTypeObject:string;
  startTime:DateTime;
  hours:integer;
  endTime:DateTime;
  views:integer;
  authhorized;string[];
  status:boolean;
  Member:string;
  documentId:string[];
}

//export interface keyTypeInterface{
	//time:enum;
	//views:enum;
	//permanent:enum
	
//}