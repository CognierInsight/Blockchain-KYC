export interface Ikey {
  id: string;
  name: string;
  type: string;
}
