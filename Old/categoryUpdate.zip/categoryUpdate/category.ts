

export interface Icategory {
  categoryId: string;
  categoryName: string;
  //documentImage: string;
 // revokeTIme:string;
  //memberId:string;
  //categoryId: string;
}