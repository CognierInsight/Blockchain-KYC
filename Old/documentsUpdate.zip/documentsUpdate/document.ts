

export interface Idocument {
  documentId: string;
  documentName: string;
  documentImage: string;
  revokeTIme:string;
  memberId:string;
  categoryId: string;
}